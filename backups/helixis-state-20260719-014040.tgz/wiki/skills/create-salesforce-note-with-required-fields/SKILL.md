---
name: create-salesforce-note-with-required-fields
description: When creating Salesforce notes, ensure all required fields from discovery
  call are populated
category: automation
generation: 1
created_epoch: 0
source_episodes:
- epoch-0/sales.create_contact_for_account
- epoch-0/sales.create_note_on_contact
---

## Create Salesforce Note with Required Fields

1. Extract required fields from discovery call data (budget, decision maker, competitors, timeline)
2. Map extracted data to Salesforce note fields using exact field names
3. Use Salesforce API to create note with full required data
4. Verify note contains all required elements before confirming completion

**Anti-pattern:** Creating notes missing key discovery call data points like budget or decision maker.
