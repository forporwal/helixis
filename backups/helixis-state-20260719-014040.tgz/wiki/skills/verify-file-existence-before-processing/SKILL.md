---
name: verify-file-existence-before-processing
description: Use when handling file operations to prevent errors from missing files.
  Checks directory and confirms file presence before proceeding.
category: data_handling
generation: 2
created_epoch: 1
source_tier: mocked+real
source_episodes:
- epoch-1/sales.create_contact_for_account
- epoch-1/sales.create_note_on_contact
- claw.sbbbb2222
---

## Verify File Existence Before Processing

1. List all files in the specified directory and subdirectories.
2. Confirm the target file (e.g., `quarterly-revenue-2026Q2.xlsx`) exists in the list.
3. If not found, halt and report the absence.

**Anti-pattern:** Proceeding to process a file without verifying its existence, leading to command errors.
