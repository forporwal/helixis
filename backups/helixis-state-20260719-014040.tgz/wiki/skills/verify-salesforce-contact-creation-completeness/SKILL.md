---
name: verify-salesforce-contact-creation-completeness
description: Use after creating a Salesforce contact to ensure all required fields
  and counts are validated. Prevents partial or missing contact records.
category: verification
generation: 2
created_epoch: 1
source_tier: mocked+real
source_episodes:
- epoch-1/sales.create_contact_for_account
- epoch-1/sales.create_note_on_contact
- claw.sbbbb2222
---

## Verify Salesforce Contact Creation Completeness

1. Confirm the contact was created via API or UI.
2. Check `salesforce_contact_exists_with_field` for critical fields (email, name, account ID).
3. Validate `salesforce_collection_count_equals` matches expected contact count.

**Anti-pattern:** Assuming contact creation succeeded without verifying existence or count mismatches.
