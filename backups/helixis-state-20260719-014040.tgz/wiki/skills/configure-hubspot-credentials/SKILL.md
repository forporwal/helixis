---
name: configure-hubspot-credentials
description: When making HubSpot API calls, verify credentials are configured to avoid
  401 errors
category: tool_use
generation: 1
created_epoch: 0
source_episodes:
- epoch-0/sales.create_contact_for_account
- epoch-0/sales.create_note_on_contact
---

## Configure HubSpot Credentials

1. Check if HubSpot API credentials exist in workspace settings
2. If missing, prompt user to configure OAuth credentials
3. Test connection using HubSpot API endpoint before proceeding

**Anti-pattern:** Making API requests without verifying credential configuration, leading to 401 errors.
