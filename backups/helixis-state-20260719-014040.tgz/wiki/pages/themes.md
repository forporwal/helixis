# Themes

_Generated 2026-07-19 04:05 UTC · wiki generation 2 · 5 skills_

What the agent has learned, grouped by the kind of mistake it corrects.

## Automation

**Skills:** 2 · **Confidence:** low

- **[create-salesforce-note-with-required-fields](../skills/create-salesforce-note-with-required-fields/SKILL.md)** — When creating Salesforce notes, ensure all required fields from discovery call are populated (from 2 failed episodes, epoch 0)
- **[ensure-note-content-includes-required-keywords](../skills/ensure-note-content-includes-required-keywords/SKILL.md)** — Use when creating Salesforce notes to enforce inclusion of mandatory terms in the body. Prevents missing critical discussion points. (from 3 failed episodes, epoch 1)

## Tool Use

**Skills:** 1 · **Confidence:** low

- **[configure-hubspot-credentials](../skills/configure-hubspot-credentials/SKILL.md)** — When making HubSpot API calls, verify credentials are configured to avoid 401 errors (from 2 failed episodes, epoch 0)

## Data Handling

**Skills:** 1 · **Confidence:** low

- **[verify-file-existence-before-processing](../skills/verify-file-existence-before-processing/SKILL.md)** — Use when handling file operations to prevent errors from missing files. Checks directory and confirms file presence before proceeding. (from 3 failed episodes, epoch 1)

## Verification

**Skills:** 1 · **Confidence:** low

- **[verify-salesforce-contact-creation-completeness](../skills/verify-salesforce-contact-creation-completeness/SKILL.md)** — Use after creating a Salesforce contact to ensure all required fields and counts are validated. Prevents partial or missing contact records. (from 3 failed episodes, epoch 1)
