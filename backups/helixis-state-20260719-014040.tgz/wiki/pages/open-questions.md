# Open Questions

_Generated 2026-07-19 04:05 UTC · wiki generation 2_

Failures the current skill set has not resolved. These are the targets for the next distillation pass — and the honest limits of the result.

_No task has failed more than once with skills active._

## Skills never retrieved

Distilled but never selected by retrieval — either the trigger description is poorly worded for matching, or the situation has not recurred.

- `ensure-note-content-includes-required-keywords`
- `verify-file-existence-before-processing`
- `verify-salesforce-contact-creation-completeness`
